# Requirements

1. Jupyter Notebook
2. PyPI Packages
    - pandas
    - flask
